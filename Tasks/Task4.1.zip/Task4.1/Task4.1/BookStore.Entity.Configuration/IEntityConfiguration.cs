﻿namespace BookStore.Entity.Configuration;

public interface IEntityConfiguration
{
}
