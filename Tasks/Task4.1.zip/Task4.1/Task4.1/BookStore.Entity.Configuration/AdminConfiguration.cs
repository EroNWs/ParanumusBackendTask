﻿namespace BookStore.Entity.Configuration;

public class AdminConfiguration
{
}
