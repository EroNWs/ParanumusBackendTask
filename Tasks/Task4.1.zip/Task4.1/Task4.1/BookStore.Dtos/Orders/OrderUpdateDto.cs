﻿namespace BookStore.Dtos.Orders;

public class OrderUpdateDto
{
}
