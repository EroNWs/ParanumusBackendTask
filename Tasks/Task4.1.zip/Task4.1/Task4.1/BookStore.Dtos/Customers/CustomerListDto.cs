﻿namespace BookStore.Dtos.Customers;

public class CustomerListDto
{
}
