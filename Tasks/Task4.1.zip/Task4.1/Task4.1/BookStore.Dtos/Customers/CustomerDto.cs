﻿namespace BookStore.Dtos.Customers;

public class CustomerDto
{
}
