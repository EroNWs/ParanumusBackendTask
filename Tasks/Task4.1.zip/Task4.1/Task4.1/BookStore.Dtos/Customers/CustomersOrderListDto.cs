﻿namespace BookStore.Dtos.Customers;

public class CustomersOrderListDto
{
}
