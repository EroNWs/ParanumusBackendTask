﻿namespace BookStore.Dtos.Customers;

public class CustomerOrderDto
{
}
