﻿namespace BookStore.Entities.DbSets;

public class Admin:BaseUser
{

}
