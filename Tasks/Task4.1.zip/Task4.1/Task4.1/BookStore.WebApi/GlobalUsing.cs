﻿global using BookStore.Dal.EntityFramework.Extensions;
global using BookStore.Business.Extensions;