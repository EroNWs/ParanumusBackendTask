﻿namespace BookStore.Core.DataAccess.Interfaces;


public interface IRepository
{
    int SaveChanges();

}
