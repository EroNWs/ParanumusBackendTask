﻿global using BookStore.Core.Entities.Base;
global using BookStore.Core.DataAccess.Interfaces;