﻿namespace BookStore.Business.Interfaces;

public interface IAdminService
{
}
