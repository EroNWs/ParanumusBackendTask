﻿namespace BookStore.Business.Interfaces;

public interface IOrderService
{
}
