﻿namespace BookStore.Business.Interfaces;

public interface IUserService
{
}
