﻿global using AutoMapper;
global using BookStore.Dal.Interface.Repositories;
global using BookStore.Entities.DbSets;
global using BookStore.Business.Interfaces;