﻿global using BookStore.Entities.DbSets;
global using BookStore.Core.DataAccess.Interfaces;