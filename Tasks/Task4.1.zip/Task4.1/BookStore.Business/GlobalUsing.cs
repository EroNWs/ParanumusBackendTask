﻿global using AutoMapper;
global using BookStore.Business.Constants;
global using BookStore.Core.Utilities.Results;
global using BookStore.Core.Utilities.Results.Concrete;
global using BookStore.Dal.Interface.Repositories;
global using BookStore.Entities.DbSets;
