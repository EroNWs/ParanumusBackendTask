﻿namespace BookStore.Business.Profiles;

public class AdminProfile:Profile
{
    public AdminProfile()
    {
        
    }
}
