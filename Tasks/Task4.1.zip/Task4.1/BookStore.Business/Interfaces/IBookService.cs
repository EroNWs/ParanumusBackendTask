﻿namespace BookStore.Business.Interfaces;

public class IBookService
{
}
