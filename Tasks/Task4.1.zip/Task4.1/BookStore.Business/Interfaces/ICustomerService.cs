﻿namespace BookStore.Business.Interfaces;

public class ICustomerService
{
}
