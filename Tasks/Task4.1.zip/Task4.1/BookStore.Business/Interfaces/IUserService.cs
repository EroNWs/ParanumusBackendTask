﻿namespace BookStore.Business.Interfaces;

public class IUserService
{
}
