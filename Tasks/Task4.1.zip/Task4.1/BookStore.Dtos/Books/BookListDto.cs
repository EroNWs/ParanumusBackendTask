﻿namespace BookStore.Dtos.Books;

public class BookListDto
{
}
