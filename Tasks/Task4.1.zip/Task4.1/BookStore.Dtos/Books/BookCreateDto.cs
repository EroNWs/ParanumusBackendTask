﻿namespace BookStore.Dtos.Books;

public class BookCreateDto
{
}
