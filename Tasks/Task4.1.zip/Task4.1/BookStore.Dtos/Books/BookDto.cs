﻿namespace BookStore.Dtos.Books;

public class BookDto
{
}
