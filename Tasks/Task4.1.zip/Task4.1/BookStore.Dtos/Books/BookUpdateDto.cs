﻿namespace BookStore.Dtos.Books;

public class BookUpdateDto
{
}
