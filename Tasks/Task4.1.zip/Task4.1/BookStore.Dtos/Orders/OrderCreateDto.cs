﻿namespace BookStore.Dtos.Orders;

public class OrderCreateDto
{
}
