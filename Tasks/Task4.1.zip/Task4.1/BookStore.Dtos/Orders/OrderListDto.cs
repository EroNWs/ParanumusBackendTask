﻿namespace BookStore.Dtos.Orders;

public class OrderListDto
{
}
