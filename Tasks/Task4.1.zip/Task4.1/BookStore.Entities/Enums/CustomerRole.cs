﻿namespace BookStore.Entities.Enums;

public enum CustomerRole
{
    RegularCustomer=1,
    PremiumCustomer =2,
    CompanyEmployee=3
}
