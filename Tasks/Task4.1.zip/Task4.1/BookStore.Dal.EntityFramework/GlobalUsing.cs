﻿global using BookStore.Core.DataAccess.EntityFramework;
global using BookStore.Dal.Contexts;
global using BookStore.Dal.Interface.Repositories;
global using BookStore.Entities.DbSets;