﻿namespace BookStore.Core.Enums;

public enum Roles
{
    Admin = 1

}

